<?php
/** Copy from config/config.example.php and set secrets via the hosting file manager. */
return [
    'APP_BASE_URL' => 'https://YOUR-DOMAIN',
    'DB_HOST' => 'sqlXXX.infinityfree.com', // exact hostname shown in InfinityFree panel; never localhost
    'DB_NAME' => '',
    'DB_USER' => '',
    'DB_PASS' => '',
    'SMTP_HOST' => '',
    'SMTP_PORT' => 587,
    'SMTP_USERNAME' => '',
    'SMTP_PASSWORD' => '',
    'SMTP_ENCRYPTION' => 'tls',
    'SMTP_FROM_EMAIL' => '',
    'SMTP_FROM_NAME' => 'Student Support Portal',
];
