-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Mar 29, 2026 at 06:43 PM
-- Server version: 8.0.45-cll-lve
-- PHP Version: 8.4.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `code2025_login_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_profiles`
--

CREATE TABLE `admin_profiles` (
  `admin_id` int NOT NULL,
  `user_id` int NOT NULL,
  `department` varchar(100) DEFAULT NULL COMMENT 'e.g., csdl staff, Management, Guidance Head',
  `admin_level` enum('Super Admin','System Admin') DEFAULT 'System Admin',
  `phone_number` varchar(20) DEFAULT NULL,
  `avatar_path` varchar(255) DEFAULT 'default_admin.png',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `admin_profiles`
--

INSERT INTO `admin_profiles` (`admin_id`, `user_id`, `department`, `admin_level`, `phone_number`, `avatar_path`, `created_at`, `updated_at`) VALUES
(1, 1, 'CSDL staff', 'System Admin', '09123456789', '../uploads/admins/admin_1_1774620121.jpg', '2026-03-07 07:49:14', '2026-03-27 14:02:01'),
(6, 13, '', 'System Admin', '', '../uploads/admins/admin_13_1774613235.jpg', '2026-03-27 12:07:15', '2026-03-27 12:07:35');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `announcement_id` int NOT NULL,
  `counselor_id` int NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('ACTIVE','INACTIVE') DEFAULT 'ACTIVE',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`announcement_id`, `counselor_id`, `title`, `content`, `start_date`, `end_date`, `status`, `created_at`) VALUES
(3, 18, 'testing 1 announcement to all student', 'hello test 1', '2026-03-27', '2026-03-28', 'ACTIVE', '2026-03-27 10:41:03');

-- --------------------------------------------------------

--
-- Table structure for table `audit_logs`
--

CREATE TABLE `audit_logs` (
  `id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `table_name` varchar(50) DEFAULT NULL,
  `object_id` varchar(50) DEFAULT NULL,
  `changed_data` json DEFAULT NULL,
  `sql_text` text,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `audit_logs`
--

INSERT INTO `audit_logs` (`id`, `user_id`, `action`, `table_name`, `object_id`, `changed_data`, `sql_text`, `ip_address`, `created_at`) VALUES
(1, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-02-27 01:40:35'),
(2, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-02-27 01:40:37'),
(3, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-02-27 01:40:40'),
(4, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"student\"}', NULL, '103.72.188.50', '2026-02-28 17:54:13'),
(5, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 01:46:38'),
(6, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 02:16:31'),
(7, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 02:17:38'),
(8, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 02:18:30'),
(9, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '175.176.49.138', '2026-03-01 02:19:11'),
(10, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 02:19:40'),
(11, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 13:39:05'),
(12, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 14:22:28'),
(13, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 14:22:32'),
(14, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 14:24:35'),
(15, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 14:24:38'),
(16, 1, 'USER_DEACTIVATED', 'users', '13', '{\"username\": \"test1\", \"new_status\": \"INACTIVE\", \"previous_status\": \"ACTIVE\"}', 'UPDATE users SET status = \'INACTIVE\' WHERE user_id = ?', '49.144.215.174', '2026-03-01 14:28:45'),
(17, 1, 'USER_UPDATE', 'users', '13', '{\"role\": \"ADMIN_REPORTS\", \"email\": \"johnjericrrocesnombre@gmail.com\", \"status\": \"ACTIVE\", \"division\": \"REPORT\", \"password\": \"\", \"username\": \"test1\", \"last_name\": \"Mendez\", \"first_name\": \"Joeme\", \"middle_name\": \"G.\"}', NULL, '49.144.215.174', '2026-03-01 14:28:51'),
(18, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-01 15:47:25'),
(19, 1, 'USER_CREATE', 'users', '15', '{\"role\": \"COUNSELOR\", \"email\": \"Juanasd@example.com\", \"division\": \"COUNSELOR\", \"password\": \"12345678\", \"username\": \"testing3\", \"last_name\": \"Dela Cruz\", \"first_name\": \"Joemee\", \"middle_name\": \"Ramos\"}', NULL, '49.144.215.174', '2026-03-01 15:51:09'),
(20, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 06:18:06'),
(21, 1, 'DEACTIVATE_SUBDOMAIN', 'subdomains', '5', NULL, NULL, NULL, '2026-03-02 06:41:44'),
(22, 1, 'ACTIVATE_SUBDOMAIN', 'subdomains', '5', NULL, NULL, NULL, '2026-03-02 06:42:57'),
(23, 1, 'DEACTIVATE_SUBDOMAIN', 'subdomains', '5', NULL, NULL, NULL, '2026-03-02 06:43:01'),
(24, 1, 'ACTIVATE_SUBDOMAIN', 'subdomains', '5', NULL, NULL, NULL, '2026-03-02 06:43:03'),
(25, 1, 'DEACTIVATE_SUBDOMAIN', 'subdomains', '5', NULL, NULL, NULL, '2026-03-02 06:43:10'),
(26, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 06:45:40'),
(27, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 06:45:42'),
(28, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 08:06:33'),
(29, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 09:37:07'),
(30, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 09:49:22'),
(31, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 10:05:52'),
(32, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '136.158.35.26', '2026-03-02 10:09:49'),
(33, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '136.158.35.26', '2026-03-02 10:10:12'),
(34, 1, 'LOGOUT', 'users', '1', NULL, NULL, '136.158.35.26', '2026-03-02 10:10:57'),
(35, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '103.72.188.50', '2026-03-02 10:11:11'),
(36, 1, 'LOGOUT', 'users', '1', NULL, NULL, '103.72.188.50', '2026-03-02 10:11:59'),
(37, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '136.158.35.26', '2026-03-02 10:12:26'),
(38, 1, 'LOGOUT', 'users', '1', NULL, NULL, '136.158.35.26', '2026-03-02 10:13:42'),
(39, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 10:15:35'),
(40, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 10:16:52'),
(41, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"adminjeric\"}', NULL, '136.158.35.26', '2026-03-02 10:28:38'),
(42, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '136.158.35.26', '2026-03-02 10:28:50'),
(43, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '136.158.35.26', '2026-03-02 10:29:10'),
(44, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 10:29:16'),
(45, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 10:35:28'),
(46, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 10:44:38'),
(47, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 11:01:52'),
(48, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 11:05:26'),
(49, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-02 11:05:34'),
(50, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"admin\"}', NULL, '180.195.60.56', '2026-03-02 11:38:10'),
(51, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '175.176.48.69', '2026-03-03 01:04:12'),
(52, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '175.176.48.69', '2026-03-03 01:10:42'),
(53, 1, 'LOGOUT', 'users', '1', NULL, NULL, '175.176.48.69', '2026-03-03 01:12:01'),
(54, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-04 03:38:46'),
(55, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-04 06:03:00'),
(56, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-04 06:23:03'),
(57, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-04 06:24:14'),
(58, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-04 06:27:50'),
(59, 1, 'USER_UPDATE', 'users', '13', '{\"role\": \"ADMIN\", \"email\": \"johnjericrrocesnombre@gmail.com\", \"status\": \"ACTIVE\", \"division\": \"ADMIN\", \"password\": \"12345678\", \"username\": \"test1\", \"last_name\": \"Mendez\", \"first_name\": \"Joeme\", \"middle_name\": \"G.\"}', NULL, '49.144.215.174', '2026-03-04 06:44:31'),
(60, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-04 06:44:35'),
(61, 13, 'LOGIN_SUCCESS', 'users', '13', NULL, NULL, '49.144.215.174', '2026-03-04 06:44:44'),
(62, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-04 06:55:43'),
(63, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-04 12:22:38'),
(64, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-04 13:16:38'),
(65, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-04 13:32:36'),
(66, 13, 'LOGIN_SUCCESS', 'users', '13', NULL, NULL, '110.54.183.234', '2026-03-04 13:33:39'),
(67, 1, 'USER_CREATE', 'users', '16', '{\"role\": \"ADMIN\", \"email\": \"test@gmail.com\", \"division\": \"ADMIN\", \"password\": \"12345678\", \"username\": \"user1\", \"last_name\": \"test\", \"first_name\": \"test\", \"middle_name\": \"test\"}', NULL, '49.144.215.174', '2026-03-04 13:34:54'),
(68, 1, 'USER_CREATE', 'users', '17', '{\"role\": \"COUNSELOR\", \"email\": \"test1@gmail.com\", \"division\": \"COUNSELOR\", \"password\": \"12345678\", \"username\": \"user2\", \"last_name\": \"test1\", \"first_name\": \"test1\", \"middle_name\": \"test1\"}', NULL, '49.144.215.174', '2026-03-04 13:35:29'),
(69, 1, 'USER_UPDATE', 'users', '17', '{\"role\": \"STUDENT\", \"email\": \"test1@gmail.com\", \"status\": \"ACTIVE\", \"division\": \"STUDENT\", \"password\": \"\", \"username\": \"user2\", \"last_name\": \"test1\", \"first_name\": \"test1\", \"middle_name\": \"test1\"}', NULL, '49.144.215.174', '2026-03-04 13:36:49'),
(70, 1, 'USER_CREATE', 'users', '18', '{\"role\": \"COUNSELOR\", \"email\": \"test2@gmail.com\", \"division\": \"COUNSELOR\", \"password\": \"12345678\", \"username\": \"user3\", \"last_name\": \"test2\", \"first_name\": \"test2\", \"middle_name\": \"test2\"}', NULL, '49.144.215.174', '2026-03-04 13:37:34'),
(71, 1, 'USER_CREATE', 'users', '19', '{\"role\": \"STUDENT\", \"email\": \"test3@gmail.com\", \"division\": \"STUDENT\", \"password\": \"12345678\", \"username\": \"user4\", \"last_name\": \"test3\", \"first_name\": \"test3\", \"middle_name\": \"test3\"}', NULL, '49.144.215.174', '2026-03-04 14:08:09'),
(72, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-07 07:36:53'),
(73, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-07 09:03:15'),
(74, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-07 11:08:36'),
(75, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-08 05:05:03'),
(76, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.144.215.174', '2026-03-09 11:22:43'),
(77, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '175.176.49.135', '2026-03-16 03:13:25'),
(78, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-16 12:40:48'),
(79, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-16 12:41:38'),
(80, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '110.54.183.182', '2026-03-16 14:25:33'),
(81, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '110.54.183.182', '2026-03-16 14:39:52'),
(82, 16, 'LOGOUT', 'users', '16', NULL, NULL, '110.54.183.182', '2026-03-16 14:40:11'),
(83, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '180.194.253.150', '2026-03-18 05:19:47'),
(84, 16, 'LOGOUT', 'users', '16', NULL, NULL, '180.194.253.150', '2026-03-18 05:20:32'),
(85, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"user1\"}', NULL, '180.194.253.150', '2026-03-18 05:24:23'),
(86, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '180.194.253.150', '2026-03-18 05:24:35'),
(87, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '180.194.253.150', '2026-03-18 05:33:14'),
(88, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '209.35.169.10', '2026-03-20 11:07:23'),
(89, 16, 'LOGOUT', 'users', '16', NULL, NULL, '209.35.169.10', '2026-03-20 11:12:17'),
(90, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '49.144.237.193', '2026-03-24 08:40:54'),
(91, 16, 'LOGOUT', 'users', '16', NULL, NULL, '49.144.237.193', '2026-03-24 08:43:14'),
(92, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-24 10:48:08'),
(93, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '122.3.156.134', '2026-03-25 00:20:52'),
(94, 16, 'LOGOUT', 'users', '16', NULL, NULL, '122.3.156.134', '2026-03-25 00:21:51'),
(95, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '122.3.156.134', '2026-03-25 06:07:48'),
(96, 16, 'LOGOUT', 'users', '16', NULL, NULL, '122.3.156.134', '2026-03-25 06:08:33'),
(97, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-25 10:21:26'),
(98, 1, 'USER_UPDATE', 'users', '18', '{\"role\": \"COUNSELOR\", \"email\": \"test2@gmail.com\", \"status\": \"ACTIVE\", \"division\": \"COUNSELOR\", \"password\": \"\", \"username\": \"user3\", \"last_name\": \"test2\", \"first_name\": \"test2\", \"middle_name\": \"test2\"}', NULL, '49.147.71.72', '2026-03-25 10:23:28'),
(99, 1, 'USER_UPDATE', 'users', '19', '{\"role\": \"STUDENT\", \"email\": \"test3@gmail.com\", \"status\": \"ACTIVE\", \"division\": \"STUDENT\", \"password\": \"\", \"username\": \"user4\", \"last_name\": \"test3\", \"first_name\": \"test3\", \"middle_name\": \"test3\"}', NULL, '49.147.71.72', '2026-03-25 10:23:59'),
(100, 1, 'USER_CREATE', 'users', '20', '{\"role\": \"STUDENT\", \"email\": \"joga.mendez.ucl@phinmaed.com\", \"division\": \"STUDENT\", \"password\": \"12345678\", \"username\": \"09-2324-001934\", \"last_name\": \"Mendez\", \"first_name\": \"Joeme\", \"middle_name\": \"G.\"}', NULL, '49.147.71.72', '2026-03-25 10:27:17'),
(101, 1, 'USER_CREATE', 'users', '21', '{\"role\": \"STUDENT\", \"email\": \"chra.hernandez.ucl@phinmaed.com\", \"division\": \"STUDENT\", \"password\": \"12345678\", \"username\": \"09-2324-000806\", \"last_name\": \"Hernandez\", \"first_name\": \"Christian\", \"middle_name\": \"R.\"}', NULL, '49.147.71.72', '2026-03-25 10:28:09'),
(102, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"admin1\"}', NULL, '49.147.71.72', '2026-03-25 10:33:42'),
(103, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-25 10:33:58'),
(104, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-25 10:36:21'),
(105, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-25 18:05:18'),
(106, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-25 18:06:18'),
(107, 13, 'LOGIN_SUCCESS', 'users', '13', NULL, NULL, '49.147.71.72', '2026-03-25 20:34:37'),
(108, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 09:19:40'),
(109, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 09:55:43'),
(110, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 09:55:46'),
(111, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 10:12:05'),
(112, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 11:14:57'),
(113, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 11:45:07'),
(114, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 11:49:18'),
(115, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 16:50:47'),
(116, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 16:57:59'),
(117, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 17:04:58'),
(118, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 17:06:11'),
(119, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 17:09:37'),
(120, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 17:22:28'),
(121, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 17:23:17'),
(122, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 17:23:59'),
(123, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 17:33:11'),
(124, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-26 17:38:55'),
(125, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 03:49:37'),
(126, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 04:11:14'),
(127, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 04:11:16'),
(128, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 04:11:29'),
(129, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 04:11:36'),
(130, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 04:14:44'),
(131, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 04:14:46'),
(132, 1, 'USER_CREATE', 'users', '22', '{\"role\": \"COUNSELOR\", \"email\": \"juandeputs@gmail.com\", \"division\": \"COUNSELOR\", \"username\": \"09-2324-000910\", \"last_name\": \"Nombre\", \"first_name\": \"John\", \"middle_name\": \"Jeric R.\"}', NULL, '49.147.71.72', '2026-03-27 04:15:40'),
(133, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 04:15:43'),
(134, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 04:19:50'),
(135, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 04:19:54'),
(136, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"09-2324-000909\"}', NULL, '49.147.71.72', '2026-03-27 04:23:35'),
(137, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '58.69.192.155', '2026-03-27 04:33:52'),
(138, 16, 'LOGOUT', 'users', '16', NULL, NULL, '58.69.192.155', '2026-03-27 04:34:02'),
(139, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"user3\"}', NULL, '58.69.192.155', '2026-03-27 04:34:09'),
(140, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '58.69.192.155', '2026-03-27 04:34:44'),
(141, 16, 'LOGOUT', 'users', '16', NULL, NULL, '58.69.192.155', '2026-03-27 04:34:46'),
(142, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 04:35:01'),
(143, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 05:43:20'),
(144, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 10:50:36'),
(145, 1, 'USER_CREATE', 'users', '23', '{\"role\": \"STUDENT\", \"email\": \"m.santos@phinmaed.com\", \"division\": \"STUDENT\", \"username\": \"09-2324-000601\", \"last_name\": \"Santos\", \"first_name\": \"Maria\", \"middle_name\": \"\"}', NULL, '49.147.71.72', '2026-03-27 10:56:44'),
(146, 1, 'USER_CREATE', 'users', '24', '{\"role\": \"STUDENT\", \"email\": \"r.reyes@phinmaed.com\", \"division\": \"STUDENT\", \"username\": \"09-2324-000603\", \"last_name\": \"Reyes\", \"first_name\": \"Ricardo\", \"middle_name\": \"\"}', NULL, '49.147.71.72', '2026-03-27 10:57:29'),
(147, 1, 'USER_CREATE', 'users', '25', '{\"role\": \"STUDENT\", \"email\": \"e.garcia@phinmaed.com\", \"division\": \"STUDENT\", \"username\": \"09-2324-000604\", \"last_name\": \"Garcia\", \"first_name\": \"Elena\", \"middle_name\": \"\"}', NULL, '49.147.71.72', '2026-03-27 10:58:23'),
(148, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 11:06:52'),
(149, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 11:07:32'),
(150, 1, 'USER_UPDATE', 'users', '18', '{\"role\": \"COUNSELOR\", \"email\": \"test2@gmail.com\", \"status\": \"ACTIVE\", \"division\": \"COUNSELOR\", \"username\": \"user3\", \"last_name\": \"ric\", \"first_name\": \"riv\", \"middle_name\": \"\"}', NULL, '49.147.71.72', '2026-03-27 11:08:13'),
(151, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '103.148.60.30', '2026-03-27 11:09:06'),
(152, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"user2\"}', NULL, '103.148.60.30', '2026-03-27 11:10:29'),
(153, 1, 'USER_UPDATE', 'users', '18', '{\"role\": \"COUNSELOR\", \"email\": \"aiah@gmail.com\", \"status\": \"ACTIVE\", \"division\": \"COUNSELOR\", \"username\": \"user3\", \"last_name\": \"Arceta\", \"first_name\": \"Maraiah Queen\", \"middle_name\": \"\"}', NULL, '49.147.71.72', '2026-03-27 11:10:33'),
(154, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 11:12:57'),
(155, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 11:15:37'),
(156, 1, 'USER_UPDATE', 'users', '13', '{\"role\": \"ADMIN\", \"email\": \"johnjericrrocesnombre@gmail.com\", \"status\": \"ACTIVE\", \"division\": \"ADMIN\", \"username\": \"user12\", \"last_name\": \"Roces\", \"first_name\": \"Jeric\", \"middle_name\": \"\"}', NULL, '49.147.71.72', '2026-03-27 11:26:56'),
(157, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 11:27:05'),
(158, 13, 'LOGIN_SUCCESS', 'users', '13', NULL, NULL, '49.147.71.72', '2026-03-27 11:27:14'),
(159, 13, 'LOGIN_SUCCESS', 'users', '13', NULL, NULL, '49.147.71.72', '2026-03-27 11:30:41'),
(160, 13, 'LOGOUT', 'users', '13', NULL, NULL, '49.147.71.72', '2026-03-27 11:37:08'),
(161, 13, 'LOGIN_SUCCESS', 'users', '13', NULL, NULL, '49.147.71.72', '2026-03-27 11:37:17'),
(162, 13, 'LOGOUT', 'users', '13', NULL, NULL, '49.147.71.72', '2026-03-27 11:43:05'),
(163, 13, 'LOGIN_SUCCESS', 'users', '13', NULL, NULL, '49.147.71.72', '2026-03-27 11:43:08'),
(164, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 11:57:25'),
(165, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 12:00:50'),
(166, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 13:06:04'),
(167, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 13:10:25'),
(168, 13, 'LOGIN_SUCCESS', 'users', '13', NULL, NULL, '49.147.71.72', '2026-03-27 13:59:49'),
(169, 13, 'LOGOUT', 'users', '13', NULL, NULL, '49.147.71.72', '2026-03-27 14:01:25'),
(170, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 14:01:33'),
(171, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-27 14:02:25'),
(172, 16, 'LOGIN_SUCCESS', 'users', '16', NULL, NULL, '136.158.65.18', '2026-03-27 16:47:36'),
(173, 16, 'LOGOUT', 'users', '16', NULL, NULL, '136.158.65.18', '2026-03-27 16:48:33'),
(174, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"user12\"}', NULL, '131.226.106.166', '2026-03-28 01:38:07'),
(175, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"user3\"}', NULL, '131.226.106.166', '2026-03-28 01:38:21'),
(176, 13, 'LOGIN_SUCCESS', 'users', '13', NULL, NULL, '131.226.106.166', '2026-03-28 01:38:33'),
(177, 13, 'LOGOUT', 'users', '13', NULL, NULL, '131.226.106.166', '2026-03-28 01:40:02'),
(178, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '175.176.51.109', '2026-03-28 02:42:25'),
(179, 1, 'LOGOUT', 'users', '1', NULL, NULL, '175.176.51.109', '2026-03-28 02:42:56'),
(180, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"user3\"}', NULL, '175.176.53.245', '2026-03-28 03:28:45'),
(181, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"user3\"}', NULL, '175.176.53.245', '2026-03-28 03:29:03'),
(182, NULL, 'LOGIN_FAILED', 'users', NULL, '{\"attempted_username\": \"user12\"}', NULL, '131.226.106.102', '2026-03-28 04:25:40'),
(183, 13, 'LOGIN_SUCCESS', 'users', '13', NULL, NULL, '175.176.51.109', '2026-03-28 04:27:47'),
(184, 13, 'LOGOUT', 'users', '13', NULL, NULL, '175.176.51.109', '2026-03-28 04:30:20'),
(185, 1, 'LOGIN_SUCCESS', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-29 05:10:28'),
(186, 1, 'LOGOUT', 'users', '1', NULL, NULL, '49.147.71.72', '2026-03-29 05:10:44');

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `case_id` int NOT NULL,
  `student_user_id` int NOT NULL,
  `counselor_id` int DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `status` enum('Open','In Progress','Pending','Resolved','Closed') DEFAULT 'Open',
  `priority` enum('Low','Medium','High','Urgent') DEFAULT 'Medium',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`case_id`, `student_user_id`, `counselor_id`, `title`, `description`, `status`, `priority`, `created_at`, `updated_at`) VALUES
(55, 14, 18, 'Academic Anxiety & Midterms Stress', 'The student is feeling severely overwhelmed with the upcoming midterms and reported experiencing minor panic attacks during exams.', 'Open', 'High', '2026-02-27 11:23:43', '2026-03-28 03:09:13'),
(56, 21, 22, 'Course Shifting Consultation', 'Student is currently in BS IT but wants to shift to Criminology. Needs guidance on the process and to assess if it aligns with their career goals.', 'In Progress', 'Medium', '2026-03-27 11:23:43', '2026-03-27 11:25:17'),
(57, 20, 15, 'Financial Difficulties Affecting Studies', 'Student requested a consultation because family financial issues are causing severe distraction. Looking for part-time job recommendations or scholarship options.', 'Pending', 'Medium', '2026-03-27 11:23:43', '2026-03-27 11:25:38'),
(58, 29, 18, 'Peer Conflict / Group Work Dispute', 'Reported a verbal altercation with a blockmate regarding unfair distribution of tasks in their final project.', 'Resolved', 'Low', '2026-03-27 11:23:43', '2026-03-27 11:23:43'),
(59, 63, 22, 'Referred for Excessive Absences', 'Referred by the College Dean due to 5 consecutive absences in major subjects. Student cites personal family matters as the reason.', 'Open', 'High', '2026-03-27 11:23:43', '2026-03-27 11:23:43'),
(60, 40, 15, 'Test Anxiety & Focus Issues', 'Student needs to learn coping mechanisms and study habits for the upcoming comprehensive exams. Experiences mental blocks during tests.', 'In Progress', 'Medium', '2026-03-27 11:23:43', '2026-03-27 11:23:43'),
(61, 24, 18, 'Grief Counseling Needed', 'The student recently lost a close family member and is struggling to keep up with their academic load. Needs psychological first aid and possible endorsement for excused late submissions.', 'In Progress', 'Urgent', '2026-03-27 11:23:43', '2026-03-27 11:23:43'),
(62, 54, 22, 'Time Management / Extracurricular Balance', 'Student is a varsity athlete and is finding it difficult to balance daily training schedules with heavy coursework.', 'Open', 'Low', '2026-02-27 11:23:43', '2026-03-28 03:09:26'),
(63, 35, 15, 'Suspected Bullying & Isolation', 'Student feels isolated in class and claims that a group in their section is spreading malicious rumors about them.', 'Pending', 'High', '2026-03-27 11:23:43', '2026-03-27 11:23:43'),
(64, 48, 18, 'Routine First-Year Adjustment Check-in', 'Standard guidance check-in for freshmen. Student is adjusting well but requested tips for managing reading assignments.', 'Resolved', 'Low', '2026-03-27 11:23:43', '2026-03-27 11:23:43'),
(65, 69, 22, 'Depressive Symptoms Reported by Professor', 'A professor reported the student crying in class and appearing deeply withdrawn. Requires immediate intervention and assessment.', 'Open', 'Urgent', '2026-03-27 11:23:43', '2026-03-27 11:23:43'),
(66, 28, 15, 'Lack of Motivation / Burnout', 'Student feels extremely burned out, lacks motivation to attend classes, and is considering filing for a Leave of Absence (LOA) for the semester.', 'In Progress', 'High', '2026-03-27 11:23:43', '2026-03-27 11:23:43'),
(67, 52, 18, 'Dormitory Roommate Conflict', 'Student residing in the campus dorm is having severe disagreements with roommates regarding study times and noise levels.', 'Resolved', 'Medium', '2026-03-27 11:23:43', '2026-03-27 11:23:43'),
(68, 42, 22, 'Scholarship Grade Maintenance Stress', 'Student is under immense pressure from parents to maintain the 1.5 GWA requirement for their academic scholarship.', 'Pending', 'Medium', '2026-03-27 11:23:43', '2026-03-27 11:23:43'),
(69, 60, 15, 'Self-Esteem and Confidence Issues', 'Student expresses feelings of extreme inadequacy compared to peers, especially during class recitations and reporting.', 'Open', 'Medium', '2026-02-02 11:23:43', '2026-03-28 03:09:57'),
(70, 45, 18, 'bullying ', 'sample text', 'Pending', 'Medium', '2026-03-28 04:38:03', '2026-03-28 04:38:03');

-- --------------------------------------------------------

--
-- Table structure for table `counseling_schedules`
--

CREATE TABLE `counseling_schedules` (
  `schedule_id` int NOT NULL,
  `counselor_id` int NOT NULL,
  `student_user_id` int NOT NULL,
  `student_id` varchar(25) NOT NULL,
  `schedule_date` date NOT NULL,
  `schedule_time` time NOT NULL,
  `status` enum('Pending','Confirmed','Completed','Cancelled') DEFAULT 'Pending',
  `notes` text,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `counseling_schedules`
--

INSERT INTO `counseling_schedules` (`schedule_id`, `counselor_id`, `student_user_id`, `student_id`, `schedule_date`, `schedule_time`, `status`, `notes`, `created_at`, `updated_at`) VALUES
(4, 18, 20, '03-2023-0145', '2026-04-02', '09:00:00', 'Confirmed', 'Routine check-in for academic performance and stress management.', '2026-03-27 12:40:01', '2026-03-27 12:40:01'),
(5, 18, 21, '03-2022-0899', '2026-04-04', '13:30:00', 'Pending', 'Student requested career guidance and course shifting consultation.', '2026-03-27 12:40:01', '2026-03-27 12:40:01'),
(6, 18, 15, '03-2021-0552', '2026-03-20', '10:00:00', 'Completed', 'Discussed family issues affecting attendance. Advised to join the peer support group.', '2026-03-27 12:40:01', '2026-03-27 12:40:01'),
(7, 1, 18, '03-2024-0012', '2026-03-25', '15:00:00', 'Cancelled', 'Student cancelled due to illness. Rescheduling advised.', '2026-03-27 12:40:01', '2026-03-27 12:40:01'),
(8, 2, 22, '03-2023-0774', '2026-04-08', '11:00:00', 'Confirmed', 'Follow-up session regarding scholarship maintenance requirements.', '2026-03-27 12:40:01', '2026-03-27 12:40:01'),
(9, 18, 30, '03-2025-0101', '2026-04-10', '14:00:00', 'Pending', NULL, '2026-03-27 12:40:01', '2026-03-27 12:40:01'),
(10, 18, 28, '03-2020-0334', '2026-03-15', '08:30:00', 'Completed', 'Graduating student. Conducted exit interview and discussed post-graduation anxiety. Student is coping well overall.', '2026-03-27 12:40:01', '2026-03-27 12:40:01');

-- --------------------------------------------------------

--
-- Table structure for table `counselor_profiles`
--

CREATE TABLE `counselor_profiles` (
  `profile_id` int NOT NULL,
  `user_id` int NOT NULL,
  `specialization` varchar(100) DEFAULT NULL COMMENT 'e.g. Career Guidance, Mental Health',
  `office_location` varchar(100) DEFAULT NULL COMMENT 'e.g. Guidance Office Room 101',
  `phone_number` varchar(20) DEFAULT NULL,
  `address` text,
  `city` varchar(100) DEFAULT NULL,
  `zip_code` varchar(20) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('Male','Female','Other','Prefer not to say') DEFAULT NULL,
  `avatar_path` varchar(255) DEFAULT 'default_counselor.png',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `counselor_profiles`
--

INSERT INTO `counselor_profiles` (`profile_id`, `user_id`, `specialization`, `office_location`, `phone_number`, `address`, `city`, `zip_code`, `birth_date`, `gender`, `avatar_path`, `updated_at`) VALUES
(1, 18, 'Guidance counselor', 'ECS-106', '09123456789', 'A. Mabini st', 'Santa Cruz', '405055', '2002-03-12', 'Female', 'avatar_18_1774579164.jpg', '2026-03-27 11:11:41');

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `message_id` int NOT NULL,
  `case_id` int DEFAULT NULL,
  `sender_id` int NOT NULL,
  `recipient_id` int NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `agenda` enum('Self-Referral','Referring a Friend','General Inquiry','Follow-up','Academic Concerns') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT 'General Inquiry',
  `status` enum('Unread','Read') DEFAULT 'Unread',
  `content` text NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `read_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`message_id`, `case_id`, `sender_id`, `recipient_id`, `subject`, `agenda`, `status`, `content`, `created_at`, `read_at`) VALUES
(9, NULL, 18, 21, 'Counselor Reply', 'General Inquiry', 'Unread', 'testing 1', '2026-03-25 19:51:10', NULL),
(12, NULL, 4, 18, 'Stress', 'General Inquiry', 'Read', 'wala ng pera', '2026-03-26 14:27:08', NULL),
(13, NULL, 4, 18, 'Walang source of income', '', 'Read', 'wala ng pera', '2026-03-26 15:59:20', NULL),
(14, NULL, 4, 18, 'Stress', 'General Inquiry', 'Read', 'test1', '2026-03-26 16:00:14', NULL),
(15, NULL, 4, 15, 'Stress', 'Follow-up', 'Unread', 'nyawminyaw', '2026-03-26 17:23:58', NULL),
(16, NULL, 4, 15, 'Stress', 'Follow-up', 'Unread', 'nyawminyaw', '2026-03-26 17:23:58', NULL),
(17, NULL, 18, 4, 'Counselor Reply', 'General Inquiry', 'Unread', 'testing 1', '2026-03-27 03:42:16', NULL),
(18, NULL, 18, 4, NULL, '', 'Unread', 'hello student', '2026-03-27 05:30:46', NULL),
(19, NULL, 18, 14, NULL, '', 'Unread', 'hello student', '2026-03-27 05:30:46', NULL),
(20, NULL, 18, 17, NULL, '', 'Unread', 'hello student', '2026-03-27 05:30:46', NULL),
(21, NULL, 18, 19, NULL, '', 'Unread', 'hello student', '2026-03-27 05:30:46', NULL),
(22, NULL, 18, 20, NULL, '', 'Unread', 'hello student', '2026-03-27 05:30:46', NULL),
(23, NULL, 18, 21, NULL, '', 'Unread', 'hello student', '2026-03-27 05:30:46', NULL),
(24, NULL, 18, 4, NULL, '', 'Unread', 'hello student testing 3', '2026-03-27 06:34:24', NULL),
(25, NULL, 18, 14, NULL, '', 'Unread', 'hello student testing 3', '2026-03-27 06:34:24', NULL),
(26, NULL, 18, 17, NULL, '', 'Unread', 'hello student testing 3', '2026-03-27 06:34:24', NULL),
(27, NULL, 18, 19, NULL, '', 'Unread', 'hello student testing 3', '2026-03-27 06:34:24', NULL),
(28, NULL, 18, 20, NULL, '', 'Unread', 'hello student testing 3', '2026-03-27 06:34:24', NULL),
(29, NULL, 18, 21, NULL, '', 'Unread', 'hello student testing 3', '2026-03-27 06:34:24', NULL),
(30, NULL, 4, 15, 'No Subject', 'Follow-up', 'Unread', 'nyawminyaw', '2026-03-27 08:36:24', NULL),
(31, NULL, 18, 4, 'testing 1 announcement to all student', 'General Inquiry', 'Unread', 'hello test 1', '2026-03-27 10:41:03', NULL),
(32, NULL, 18, 14, 'testing 1 announcement to all student', 'General Inquiry', 'Unread', 'hello test 1', '2026-03-27 10:41:03', NULL),
(33, NULL, 18, 17, 'testing 1 announcement to all student', 'General Inquiry', 'Unread', 'hello test 1', '2026-03-27 10:41:03', NULL),
(34, NULL, 18, 19, 'testing 1 announcement to all student', 'General Inquiry', 'Unread', 'hello test 1', '2026-03-27 10:41:03', NULL),
(35, NULL, 18, 20, 'testing 1 announcement to all student', 'General Inquiry', 'Unread', 'hello test 1', '2026-03-27 10:41:03', NULL),
(36, NULL, 18, 21, 'testing 1 announcement to all student', 'General Inquiry', 'Unread', 'hello test 1', '2026-03-27 10:41:03', NULL),
(37, NULL, 21, 18, 'No Subject', 'Self-Referral', 'Read', 'Test', '2026-03-27 17:58:51', '2026-03-27 23:16:52'),
(38, NULL, 21, 18, 'No Subject', 'Self-Referral', 'Read', 'test123', '2026-03-28 01:23:47', '2026-03-28 01:23:54'),
(39, NULL, 18, 21, 'Counselor Reply', 'General Inquiry', 'Unread', 'hello student', '2026-03-28 01:24:30', NULL),
(40, NULL, 18, 21, 'Counselor Reply', 'General Inquiry', 'Unread', 'Hello', '2026-03-28 01:41:17', NULL),
(41, NULL, 21, 18, 'No Subject', 'Follow-up', 'Read', 'Hiii', '2026-03-28 01:41:30', '2026-03-28 01:41:39');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) DEFAULT '0',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `password_resets`
--

INSERT INTO `password_resets` (`id`, `user_id`, `token`, `expires_at`, `used`, `created_at`) VALUES
(1, 13, '266da7f5eb28269cb1722d8853e400bb540a80c30168eb2178d024ff46c4ca0c', '2026-02-10 16:12:18', 0, '2026-02-10 07:12:18'),
(2, 13, '674bab76c592ca7b1de9d90b65d4ef994eb9e30670318ce9996d468178282b45', '2026-02-14 16:50:57', 0, '2026-02-14 07:50:57'),
(3, 13, 'b811778f770557e41e42e3422879b14b97c1976f948bb805369322af7dd7671d', '2026-02-23 13:29:13', 0, '2026-02-23 04:29:13'),
(4, 13, '4a2d24b323c2330e6487a7284263dc66cf90a00e5e148717f4c806860046946a', '2026-02-25 17:12:39', 0, '2026-02-25 08:12:39'),
(5, 13, '7df8986e865305ba3cdc8197be3280b504bc05c222de157f399e09a09cd9d9d1', '2026-02-25 17:57:14', 0, '2026-02-25 08:57:14'),
(6, 13, 'e9b1f85fde70ef0694dc2f2c58167f38c2b53395b5b0d4c829d311e7fbbc09e5', '2026-02-25 18:39:36', 0, '2026-02-25 09:39:36'),
(7, 13, 'a34ab85dbc1c24a9e9b7c7946e4e17b5e1945e4a6e27f007d535f5f31baa2ded', '2026-02-26 18:39:28', 0, '2026-02-26 09:39:28'),
(8, 13, '1d6d2a5ff9ae8d1262278e8383acc376fc53b4a7648c65ca880e5716de221106', '2026-02-26 18:41:30', 0, '2026-02-26 09:41:30'),
(9, 13, 'b77d1930c305a8e3803019fdf16158d703586178a274412b03d36097a40b798d', '2026-02-26 18:43:41', 1, '2026-02-26 09:43:41'),
(10, 2, '8832d4ed706af6f09661f831ec92e08ace95454557bc055381947550abb65c14', '2026-02-26 19:01:49', 0, '2026-02-26 10:01:49'),
(11, 2, '3de332f788a61787d202d3e2f256960d5aab063e42f55e7376cf9e8c8debf03e', '2026-02-26 19:03:28', 1, '2026-02-26 10:03:28'),
(12, 10, '409b31b1dab8630d5c67f4986cd9e817de45d12aab236305d45c8deb7e193208', '2026-02-26 19:09:20', 1, '2026-02-26 10:09:20'),
(13, 2, 'a3b5e788619634d5c6c5420e9cf01edda333e3c897b8c646ab1621c00f42832b', '2026-02-26 19:11:07', 0, '2026-02-26 10:11:07'),
(14, 2, '46eb5002aa9e3fe0898331f89ca11c5df9043da813db3829d49cae02c665b0e9', '2026-02-26 19:12:52', 0, '2026-02-26 10:12:52'),
(15, 2, 'c1e3abbd07a52063e69e97d66e9d5fa3f151d92a7f20c4551748b16ebfed8fd0', '2026-02-26 19:12:56', 0, '2026-02-26 10:12:56'),
(16, 10, 'a0dc6babf076834676bef5acda8eb41a0c4b3e7d45c5c595680874cc05446a1e', '2026-02-26 19:13:20', 0, '2026-02-26 10:13:20'),
(17, 10, 'c9a80389605f2b38a22861c17feb2fda4df4650d83f312363b451b083c0f9bd9', '2026-02-26 19:16:43', 1, '2026-02-26 10:16:43'),
(18, 10, '72b6ee217d556bd1cd782c8c905881f0ba13d83a0f1c3b9fd85a422600cbf612', '2026-02-26 19:20:00', 1, '2026-02-26 10:20:00'),
(19, 10, 'c7483ec0c24d00e2b23b04d0c2e2b517f8e2a8fdda7f8b5f70a2e99c8a942dda', '2026-02-26 19:23:19', 0, '2026-02-26 10:23:19'),
(20, 10, '12e7b9185accb60e8b07a32ea36604d5bc9b9768fdbba9d770ebc6adb277b039', '2026-02-26 19:23:30', 1, '2026-02-26 10:23:30'),
(21, 10, '39614a79728d6cff49d8a1c35be93375f7ddaaccd2c9ddfc43f49cce7e533c10', '2026-02-26 19:29:13', 1, '2026-02-26 10:29:13'),
(22, 10, '8982711e60a52bff06adc392a4da31def883566414e3882174cf18c4e1fda950', '2026-02-26 19:35:33', 1, '2026-02-26 10:35:33'),
(23, 10, '24af202dc460214a8461afd6568f9fb528d4522efa1facf7dc2f877013cd3774', '2026-02-26 19:39:29', 1, '2026-02-26 10:39:29'),
(24, 10, '9fe67fd02fec72c4acc9b408726bab92d61dc10edd628fc6bc89ecbe17cd939e', '2026-02-26 19:41:01', 0, '2026-02-26 10:41:01'),
(25, 10, '91d7f4819c0461468f1685e01b048004edbafe4d29b5ae941baceacfd1fa8bd4', '2026-02-26 19:43:17', 1, '2026-02-26 10:43:17'),
(26, 10, '9da020e37cabc27e276b6d93dff177c8c67bcf92dc0db9fd4a25e0730d0eb84d', '2026-02-26 19:52:50', 1, '2026-02-26 10:52:50'),
(27, 10, '6ae7ee1077b3711a14f5a3c2fac8ffbd60ecfa6f22fc680068aea3b500f8f622', '2026-02-26 19:54:17', 0, '2026-02-26 10:54:17'),
(28, 10, 'ad9155f261581d7df3335e02118d2ffa22dcb0019db66c5dd71a5b51631a28d1', '2026-02-26 19:56:09', 1, '2026-02-26 10:56:09'),
(29, 10, '8c0813e4589863c89dc0830b2e412269a77cc386eb00a9cfe9fc2869453603bb', '2026-02-26 19:58:58', 1, '2026-02-26 10:58:58'),
(30, 10, '4fcbd78b6bedca1eafd9b07f673cf8e994790b99fe623d8fcd4e1e3f6c6bf5de', '2026-02-26 20:02:53', 1, '2026-02-26 11:02:53'),
(31, 10, 'ab6f6b68f2acc2e536bda32186979050395afdc4f59a222e5208725b0bfcbeba', '2026-02-26 20:09:26', 1, '2026-02-26 11:09:26'),
(32, 10, '10134045e1ca4efd61a2d3443d399b7aac17537c100f4bfd285494e34bff8e0d', '2026-02-26 20:16:53', 0, '2026-02-26 11:16:53'),
(33, 10, 'e88cefd77db613bcf6d0b1a325aaa1a4befb051ae8a3929041c0fe3d2ed101ec', '2026-02-26 20:17:33', 1, '2026-02-26 11:17:33'),
(34, 10, '17ae05f3bace894baeac6d2bfbb2fd2012a47b26b48020473ec70cf90939178f', '2026-02-26 20:45:01', 1, '2026-02-26 11:45:01'),
(35, 1, 'eec8a28f75827f1fec6af9ad6f671e79bf45f1daecf7ee632621ee4507897566', '2026-02-27 09:55:27', 0, '2026-02-27 00:55:27'),
(36, 1, '7f41a55536307a41e927ecd5da2e0174b83a37d40e103f6d4f572d934d54558f', '2026-02-27 09:56:39', 0, '2026-02-27 00:56:39'),
(37, 1, '2cb108d51def2a0b9178420ec2125c384906228001bd4d2ad7295bcb23a0a621', '2026-02-27 10:04:25', 0, '2026-02-27 01:04:25'),
(38, 13, '34c108059e95e4e701a6dd28146629e215a667b2cf26010645fd656c15841ea4', '2026-02-27 10:06:20', 1, '2026-02-27 01:06:20'),
(39, 10, '9924224177f953d6c2cb80f363e4c190954b182d93fa8e2a4dbdd5e6209a3f19', '2026-02-27 11:09:31', 1, '2026-02-27 02:09:31'),
(40, 10, 'd64ada3867155f45a2280aa6a57227db5575fdafd32b5296f7724b82782bb066', '2026-02-27 11:59:28', 0, '2026-02-27 02:59:28'),
(41, 10, 'fc18585d78e083cd0ae7f86c65008fdbb5475c2653f8d7bc9d89a405acbb9646', '2026-02-27 12:03:16', 0, '2026-02-27 03:03:16'),
(42, 10, '7430b5e3da209b0afe22c67e992a73d00a39230990e7c6ac54d1bfb26c8e26e8', '2026-02-27 12:06:52', 1, '2026-02-27 03:06:52'),
(43, 10, '4a4931bfdf2796f0b67662cd60dfdb4479f014e30907ad8f79d2c876fecfabe8', '2026-02-27 12:20:02', 1, '2026-02-27 03:20:02'),
(44, 10, 'dc7c899b2347365ca93cc934aa404cc5284448e99b281b5874cb0550e6695a5e', '2026-02-27 12:28:00', 1, '2026-02-27 03:28:00'),
(45, 10, '4afd4af0ed3d5f02e0ab1bb3881f8b7df73399d824fd67662a8e9624bda666a6', '2026-03-01 00:59:58', 1, '2026-02-28 15:59:58'),
(46, 14, 'a67ee440c029b670b152095cac873c9f511dacea60121afbabcea847381deb82', '2026-03-01 11:35:59', 0, '2026-03-01 02:35:59'),
(47, 10, '1e84afcbfd4434f83efc8ef69e355ecddb2e6027bfc65f7fa3a5c430383018a5', '2026-03-02 19:01:34', 0, '2026-03-02 10:01:34'),
(48, 2, 'a310d91327250c5e237c3857dc808a325f6f28551da2d2ade2e2310e5e052d4a', '2026-03-02 19:01:34', 0, '2026-03-02 10:01:34'),
(49, 13, '1fa7e5812661f5769b088e69deaa7d44d3fbb4821fee1484cb1e9c6ceb2378d0', '2026-03-02 19:03:44', 0, '2026-03-02 10:03:44'),
(50, 10, '1f58ed40e430555feefdde8b8718dfe0241e9ea9d0963a7265609847b95187af', '2026-03-04 13:04:51', 0, '2026-03-04 04:04:51'),
(51, 10, '76135112e1effab1e95878959bba3a0b9de2fd91e8f9f29f6296aef006f2fb82', '2026-03-24 03:04:14', 0, '2026-03-23 18:04:14'),
(52, 13, '49fd926f549573bc8aafa3b3222b384fde62de821e93d029f6dc3d37e571b4fc', '2026-03-26 05:33:25', 1, '2026-03-25 20:33:25'),
(53, 22, '81aa4148d4f6da7d50923a5e89bc23dc75d948d815fbeabfd9b22be7da812c1d', '2026-03-27 13:16:06', 1, '2026-03-27 04:16:06'),
(54, 22, '1228c46c34ee96c4519703c3bb2156fe237306401bd7d45725864e52335ebda2', '2026-03-27 13:22:06', 0, '2026-03-27 04:22:06'),
(55, 22, '11d5405519e229f89eb21989f6c81b0c0cb52a4ddf1606947076fdc6eb78012b', '2026-03-27 13:23:00', 1, '2026-03-27 04:23:00'),
(56, 22, 'be4cc616f25df5c3e5c192d6a649c3a29617716e2d822b4f44243d84c1df83dc', '2026-03-27 13:34:18', 1, '2026-03-27 04:34:18'),
(57, 14, '88aead5ef6446acf506959c906b0e830bd0d238460fe6bbed83b30556b639b62', '2026-03-27 13:54:50', 1, '2026-03-27 04:54:50'),
(58, 14, '81e76f9e189e62ab1892cdc3f2daeda096e851fc88e811fb81e3f99ecd70082c', '2026-03-27 13:58:15', 0, '2026-03-27 04:58:15'),
(59, 14, '2ddca950ed21073d64bd0d0e10cf893e977e854d8e6ef8586c73a85399be4e08', '2026-03-27 13:59:02', 1, '2026-03-27 04:59:02'),
(60, 14, 'fa5c290d9c8b5ce98030ffc6f6bd7c39297dd3498b73102a662bff35c3c067a6', '2026-03-27 14:01:20', 1, '2026-03-27 05:01:20');

-- --------------------------------------------------------

--
-- Table structure for table `student_profiles`
--

CREATE TABLE `student_profiles` (
  `profile_id` int NOT NULL,
  `user_id` int NOT NULL,
  `student_id` varchar(25) NOT NULL,
  `program` varchar(100) DEFAULT NULL COMMENT 'e.g. BS Information Technology',
  `year_level` enum('1st Year','2nd Year','3rd Year','4th Year','Irregular') DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `address` text,
  `city` varchar(100) DEFAULT NULL,
  `zip_code` varchar(20) DEFAULT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `gender` enum('Male','Female','Other','Prefer not to say') DEFAULT NULL,
  `guardian_name` varchar(150) DEFAULT NULL,
  `guardian_contact` varchar(20) DEFAULT NULL,
  `avatar_path` varchar(255) DEFAULT 'default_student.png',
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `student_profiles`
--

INSERT INTO `student_profiles` (`profile_id`, `user_id`, `student_id`, `program`, `year_level`, `phone_number`, `address`, `city`, `zip_code`, `religion`, `birth_date`, `gender`, `guardian_name`, `guardian_contact`, `avatar_path`, `updated_at`) VALUES
(3, 4, '', 'BS Information Technology', '1st Year', '09171234567', '123 Sample Street, Brgy. Example', 'Quezon City', '1100', 'Roman Catholic', '2003-01-01', 'Female', 'Roberto Dela Cruz', '09181234567', '/assets/images/avatars/4_1772959475.jpg', '2026-03-08 08:44:35'),
(7, 19, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'user_19_1772947336.jpg', '2026-03-08 05:22:16'),
(8, 17, '09-2324-000123', 'BS Information Technology', '1st Year', '09171234567', 'Udia', 'Cavinti', '1100', 'Roman Catholic', '2003-12-08', 'Male', 'Maria Dela Cruz', '09181234567', '/assets/images/avatars/17_1772960053.png', '2026-03-25 08:05:00'),
(9, 14, '09-2324-000909', 'BSIT', '1st Year', '09123456789', '', '', '4009', 'Aglipayan', '2004-12-12', 'Male', 'Shermirose R. Nombre', '09123456789', '/assets/images/avatars/14_1774590323.jpg', '2026-03-27 05:45:23'),
(10, 21, '09-2324-000806', 'BS Information Technology', '3rd Year', '09304719778', 'Cavinti', 'Laguna', '4013', 'Aglipayan', '2003-05-08', 'Male', 'Flore Hernandez', '09089622619', '/assets/images/avatars/21_1774605602.jpg', '2026-03-27 10:56:26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `division` enum('ADMIN','COUNSELOR','STUDENT','REPORT') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `role` enum('ADMIN','COUNSELOR','STUDENT','ADMIN_REPORTS') CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `status` enum('ACTIVE','INACTIVE') DEFAULT 'ACTIVE',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `first_name`, `middle_name`, `last_name`, `email`, `username`, `password_hash`, `division`, `role`, `status`, `created_at`) VALUES
(1, 'John Jeric', 'Roces', 'Nombre', 'riic@example.com', 'adminjeric', '$2y$10$RdBld7IgxtPXwMG8T22QbOfyqoAfOUUY67K7XDHARwju9dmwF4We6', 'ADMIN', 'ADMIN', 'ACTIVE', '2026-02-01 04:15:15'),
(4, 'student Juan', 'Cruz', 'Dela Cruz', 'studentJuan@example.com', 'student', '$2y$10$96aoVSo7mrJGvJxx5A8h4ehurfz2hGdNshmLTCKGaz9aKZj2pnliO', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-02-01 06:12:43'),
(11, 'admin1 testing', 'testing', 'testing', 'testingadmin1@example.com', 'admin1', '$2y$10$CU0WNuGoCPiXZsO3L/dg/OYb4gpDHNtNgkm/PleQMVIfwLcon3Vgi', 'ADMIN', 'ADMIN', 'ACTIVE', '2026-02-04 01:56:47'),
(12, 'admin2 testing', 'testing', 'testing', 'testingadmin2@example.com', 'admin2', '$2y$10$nN7bUHG3vL56Brwnshg42uHpEF8meGZ5RfIRqzSXZQgwKur48cCbC', 'ADMIN', 'ADMIN', 'ACTIVE', '2026-02-04 01:59:04'),
(13, 'Jeric', '', 'Roces', 'johnjericrrocesnombre@gmail.com', 'user12', '$2y$10$vQo6OQZJkcmdvpr2godl9uDPoSgmJx7GMENgGhg4VUejqYJDmNYSu', 'ADMIN', 'ADMIN', 'ACTIVE', '2026-02-10 07:12:18'),
(14, 'John Jeric', 'Roces', 'Nombre', 'joro.nombre.ucl@phinmaed.com', '09-2324-000909', '$2y$10$Ezuf.UQqXN06X819tjlra.Lc2ZBtTYC3Q74fadv/3n5iWh3ulew5K', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-01 02:35:59'),
(15, 'Joemee', 'Ramos', 'Dela Cruz', 'Juanasd@example.com', 'testing3', '$2y$10$5ly5RfR7.WBUQuV7jyPaFeR3vJJ8ldIjziuuddIBeN3XWfo6WzqD6', 'COUNSELOR', 'COUNSELOR', 'ACTIVE', '2026-03-01 15:51:09'),
(16, 'test', 'test', 'test', 'test@gmail.com', 'user1', '$2y$10$PxiQjOcaS4ILjgQJU1Kz7u8TqMPimcZoOdsdRuwlinF1Nl5JprCBe', 'ADMIN', 'ADMIN', 'ACTIVE', '2026-03-04 13:34:54'),
(17, 'test1', 'test1', 'test1', 'test1@gmail.com', 'user2', '$2y$10$DbJ1OzVf4Ydzvs2TbS5mxuPIeo2ywD5MSIbc3CNPRUves1hFend3W', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-04 13:35:29'),
(18, 'Maraiah Queen', '', 'Arceta', 'aiah@gmail.com', 'user3', '$2y$10$JDzbaGz9gKYXJImLnpuBPO8gCCnHjjPesOkHoZn9iWqom//Hs3tl6', 'COUNSELOR', 'COUNSELOR', 'ACTIVE', '2026-03-04 13:37:34'),
(19, 'test3', 'test3', 'test3', 'test3@gmail.com', 'user4', '$2y$10$274aozialCN9W7B.EF/M4upH6ATsQe1KeMmqGIoHivEFCZfBEBzFa', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-04 14:08:09'),
(20, 'Joeme', 'G.', 'Mendez', 'joga.mendez.ucl@phinmaed.com', '09-2324-001934', '$2y$10$TkU4AImXdSTJ2EHTB32QhOpFVsVuzsWH5GOMbRtWLMkVgHSa3LPu2', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-25 10:27:17'),
(21, 'Christian', 'R.', 'Hernandez', 'chra.hernandez.ucl@phinmaed.com', '09-2324-000806', '$2y$10$Cj0U53Va36E/AJQGAiwku.7UobCq7v62Hv04gRxD1qK6DSvbv6PDS', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-25 10:28:09'),
(22, 'John', 'Jeric R.', 'Nombre', 'juandeputs@gmail.com', '09-2324-000910', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'COUNSELOR', 'COUNSELOR', 'ACTIVE', '2026-03-27 04:15:40'),
(23, 'Maria', '', 'Santos', 'm.santos@phinmaed.com', '09-2324-000601', '', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 10:56:44'),
(24, 'Ricardo', '', 'Reyes', 'r.reyes@phinmaed.com', '09-2324-000603', '', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 10:57:29'),
(25, 'Elena', '', 'Garcia', 'e.garcia@phinmaed.com', '09-2324-000604', '', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 10:58:23'),
(26, 'Roberto', NULL, 'Bautista', 'r.bautista@phinmaed.com', '09-2324-000605', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(27, 'Angela', NULL, 'Mendoza', 'a.mendoza@phinmaed.com', '09-2324-000606', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(28, 'Ferdinand', NULL, 'Marcoso', 'f.marcoso@phinmaed.com', '09-2324-000607', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(29, 'Christina', NULL, 'Lopez', 'c.lopez@phinmaed.com', '09-2324-000608', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(30, 'Antonio', NULL, 'Luna', 'a.luna@phinmaed.com', '09-2324-000609', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(31, 'Teresa', NULL, 'Rizal', 't.rizal@phinmaed.com', '09-2324-000610', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(32, 'Paolo', NULL, 'Pascual', 'p.pascual@phinmaed.com', '09-2324-000611', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(33, 'Beatrice', NULL, 'Aquino', 'b.aquino@phinmaed.com', '09-2324-000612', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(34, 'Gabriel', NULL, 'Concepcion', 'g.concepcion@phinmaed.com', '09-2324-000613', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(35, 'Sofia', NULL, 'Valdez', 's.valdez@phinmaed.com', '09-2324-000614', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(36, 'Manuel', NULL, 'Quezon', 'm.quezon@phinmaed.com', '09-2324-000615', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(37, 'Isabel', NULL, 'Dizon', 'i.dizon@phinmaed.com', '09-2324-000616', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(38, 'Emilio', NULL, 'Aguinaldo', 'e.aguinaldo@phinmaed.com', '09-2324-000617', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(39, 'Lani', NULL, 'Mercado', 'l.mercado@phinmaed.com', '09-2324-000618', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(40, 'Jose', NULL, 'Protacio', 'j.protacio@phinmaed.com', '09-2324-000619', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(41, 'Rosa', NULL, 'Rosario', 'r.rosario@phinmaed.com', '09-2324-000620', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(42, 'Victor', NULL, 'Magtanggol', 'v.magtanggol@phinmaed.com', '09-2324-000621', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(43, 'Katrina', NULL, 'Halili', 'k.halili@phinmaed.com', '09-2324-000622', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(44, 'Leonora', NULL, 'Rivera', 'l.rivera@phinmaed.com', '09-2324-000623', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(45, 'Andres', NULL, 'Bonifacio', 'a.bonifacio@phinmaed.com', '09-2324-000624', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(46, 'Melchora', NULL, 'Aquino', 'm.aquino@phinmaed.com', '09-2324-000625', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(47, 'Francisco', NULL, 'Balagtas', 'f.balagtas@phinmaed.com', '09-2324-000626', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(48, 'Gregoria', NULL, 'De Jesus', 'g.dejesus@phinmaed.com', '09-2324-000627', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(49, 'Apolinario', NULL, 'Mabini', 'a.mabini@phinmaed.com', '09-2324-000628', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(50, 'Gabriela', NULL, 'Silang', 'g.silang@phinmaed.com', '09-2324-000629', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(51, 'Juan', NULL, 'Luna', 'j.luna@phinmaed.com', '09-2324-000630', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(52, 'Corazon', NULL, 'Cojuangco', 'c.cojuangco@phinmaed.com', '09-2324-000631', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(53, 'Benigno', NULL, 'Ramos', 'b.ramos@phinmaed.com', '09-2324-000632', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(54, 'Miriam', NULL, 'Santiago', 'm.santiago@phinmaed.com', '09-2324-000633', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(55, 'Rodrigo', NULL, 'Duterte', 'r.duterte@phinmaed.com', '09-2324-000634', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(56, 'Leni', NULL, 'Robredo', 'l.robredo@phinmaed.com', '09-2324-000635', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(57, 'Ferdinand', NULL, 'Romualdez', 'f.romualdez@phinmaed.com', '09-2324-000636', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(58, 'Sara', NULL, 'Zimmerman', 's.zimmerman@phinmaed.com', '09-2324-000637', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(59, 'Isko', NULL, 'Moreno', 'i.moreno@phinmaed.com', '09-2324-000638', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(60, 'Vico', NULL, 'Sotto', 'v.sotto@phinmaed.com', '09-2324-000639', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(61, 'Grace', NULL, 'Poe', 'g.poe@phinmaed.com', '09-2324-000640', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(62, 'Cynthia', NULL, 'Villar', 'c.villar@phinmaed.com', '09-2324-000641', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(63, 'Manny', NULL, 'Pacquiao', 'm.pacquiao@phinmaed.com', '09-2324-000642', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(64, 'Bong', NULL, 'Go', 'b.go@phinmaed.com', '09-2324-000643', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(65, 'Loren', NULL, 'Legarda', 'l.legarda@phinmaed.com', '09-2324-000644', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(66, 'Francis', NULL, 'Escudero', 'f.escudero@phinmaed.com', '09-2324-000645', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(67, 'Alan', NULL, 'Cayetano', 'a.cayetano@phinmaed.com', '09-2324-000646', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(68, 'Risa', NULL, 'Hontiveros', 'r.hontiveros@phinmaed.com', '09-2324-000647', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(69, 'Jinggoy', NULL, 'Estrada', 'j.estrada@phinmaed.com', '09-2324-000648', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(70, 'Bam', NULL, 'Aquino', 'b.aquino2@phinmaed.com', '09-2324-000649', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09'),
(71, 'Nancy', NULL, 'Binay', 'n.binay@phinmaed.com', '09-2324-000650', '$2y$10$OF5TsEyR33okcnxd4Ds7TunfwOOsdOuTVxkx/zIHxnkrOjmwRL222', 'STUDENT', 'STUDENT', 'ACTIVE', '2026-03-27 11:05:09');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_profiles`
--
ALTER TABLE `admin_profiles`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`announcement_id`),
  ADD KEY `counselor_id` (`counselor_id`);

--
-- Indexes for table `audit_logs`
--
ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`case_id`),
  ADD KEY `fk_student` (`student_user_id`),
  ADD KEY `fk_counselor` (`counselor_id`);

--
-- Indexes for table `counseling_schedules`
--
ALTER TABLE `counseling_schedules`
  ADD PRIMARY KEY (`schedule_id`),
  ADD KEY `counselor_id` (`counselor_id`),
  ADD KEY `student_user_id` (`student_user_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `counselor_profiles`
--
ALTER TABLE `counselor_profiles`
  ADD PRIMARY KEY (`profile_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`message_id`),
  ADD KEY `fk_message_case` (`case_id`),
  ADD KEY `fk_sender` (`sender_id`),
  ADD KEY `fk_recipient` (`recipient_id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD PRIMARY KEY (`id`),
  ADD KEY `token` (`token`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `student_profiles`
--
ALTER TABLE `student_profiles`
  ADD PRIMARY KEY (`profile_id`),
  ADD UNIQUE KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_profiles`
--
ALTER TABLE `admin_profiles`
  MODIFY `admin_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `announcement_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `audit_logs`
--
ALTER TABLE `audit_logs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=187;

--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `case_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `counseling_schedules`
--
ALTER TABLE `counseling_schedules`
  MODIFY `schedule_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `counselor_profiles`
--
ALTER TABLE `counselor_profiles`
  MODIFY `profile_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `message_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `password_resets`
--
ALTER TABLE `password_resets`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT for table `student_profiles`
--
ALTER TABLE `student_profiles`
  MODIFY `profile_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_profiles`
--
ALTER TABLE `admin_profiles`
  ADD CONSTRAINT `fk_admin_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `announcements`
--
ALTER TABLE `announcements`
  ADD CONSTRAINT `fk_counselor_announcement` FOREIGN KEY (`counselor_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `cases`
--
ALTER TABLE `cases`
  ADD CONSTRAINT `fk_counselor` FOREIGN KEY (`counselor_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_student` FOREIGN KEY (`student_user_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `counselor_profiles`
--
ALTER TABLE `counselor_profiles`
  ADD CONSTRAINT `fk_counselor_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `fk_message_case` FOREIGN KEY (`case_id`) REFERENCES `cases` (`case_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_recipient` FOREIGN KEY (`recipient_id`) REFERENCES `users` (`user_id`),
  ADD CONSTRAINT `fk_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`user_id`);

--
-- Constraints for table `student_profiles`
--
ALTER TABLE `student_profiles`
  ADD CONSTRAINT `fk_student_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
