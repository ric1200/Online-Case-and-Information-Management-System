<?php
declare(strict_types=1);

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/../public_html/shared/config/mail_config.php';

$submitted = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $identifier = trim($_POST['identifier'] ?? '');

    if (!empty($identifier)) {

        // Hanapin user sa DB gamit email o username
        $stmt = $pdo->prepare("
            SELECT user_id, email, username
            FROM users
            WHERE email = :identifier
               OR username = :identifier
            LIMIT 1
        ");
        $stmt->execute(['identifier' => $identifier]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Always show success message
        $submitted = true;

        if ($user) {
            // Generate token at expiration
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

            // Store token sa DB
            $stmt = $pdo->prepare("
                INSERT INTO password_resets (user_id, token, expires_at)
                VALUES (:user_id, :token, :expires_at)
            ");
            $stmt->execute([
                'user_id'    => $user['user_id'],
                'token'      => $token,
                'expires_at' => $expires
            ]);

            // Reset link sa reports.codeflix.site
            $link = "https://reports.codeflix.site/set-password.php?token=" . urlencode($token);

            $subject = "Counseling Office Reset Request";

            $body = "
                <p>Good day,</p>
                <p>A request was made to reset the password for your Counseling Office account.</p>
                <p><strong>Username:</strong> {$user['username']}</p>
                <p>Click the link below to reset your password:</p>
                <p><a href='{$link}'>Reset Password</a></p>
                <p>This link will expire in <strong>1 hour</strong>.</p>
                <p>If you did not request this reset, please ignore this email.</p>
                <p>- Counseling Office System Administrator</p>
            ";

            sendSystemEmail($user['email'], $subject, $body);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Forgot Password</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="/assets/css/forget-password.css">
<style>
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: "Segoe UI", Arial, sans-serif;
}

body {
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    
    background: 
        linear-gradient(rgba(0,0,0,0.45), rgba(0,0,0,0.45)),
        url("/assets/image/images.jpg") no-repeat center center;
    background-size: cover;
}

.box {
    width: 100%;
    max-width: 400px;
    padding: 30px 25px;
    background-color: rgba(255,255,255,0.95);
    border-radius: 10px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    text-align: center;
}

h2 {
    font-size: 28px;
    font-weight: 600;
    margin-bottom: 20px;
    color: #1a1a1a;
}

input[type="text"] {
    width: 100%;
    padding: 12px 15px;
    font-size: 15px;
    border-radius: 6px;
    border: 1px solid #ccc;
    margin-bottom: 18px;
    transition: all 0.2s ease;
}

input[type="text"]:focus {
    border: 2px solid #1a73e8;
    outline: none;
    box-shadow: 0 0 8px rgba(26,115,232,0.2);
}

button {
    width: 100%;
    padding: 12px;
    font-size: 15px;
    border-radius: 6px;
    border: none;
    background-color: #1a73e8;
    color: white;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
}

button:hover {
    background-color: #1765cc;
    box-shadow: 0 4px 10px rgba(26,115,232,0.3);
}

.info {
    font-size: 15px;
    color: #065f46;
    background-color: #ecfdf5;
    padding: 12px;
    border-radius: 6px;
    margin-bottom: 18px;
}

.back-link {
    display: inline-block;
    margin-top: 15px;
    font-size: 14px;
    color: #1a73e8;
    text-decoration: none;
}

.back-link:hover {
    text-decoration: underline;
}
</style>
</head>
<body>

<div class="box">
    <h2>Forgot Password</h2>

    <?php if ($submitted): ?>
        <p class="info">
            If the account exists, a password reset email has been sent.<br>
            Please check your inbox.
        </p>
        <!-- Correct Return to Login -->
        <a class="back-link" href="https://reports.codeflix.site/index.php">Return to Login</a>

    <?php else: ?>
        <form method="POST">
            <input type="text" name="identifier" placeholder="Email or Username" required>
            <button type="submit">Send Reset Link</button>
        </form>
        <!-- Correct Return to Login -->
        <a class="back-link" href="https://reports.codeflix.site/index.php">Return to Login</a>
    <?php endif; ?>
</div>

</body>
</html>