<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
require __DIR__ . '/config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    die('Invalid request.');
}

if (empty($_POST['username']) || empty($_POST['password'])) {
    die('Please enter username and password.');
}

$username = trim($_POST['username']);
$password = $_POST['password'];
$stmt = $pdo->prepare("
    SELECT user_id, role, division, password_hash
    FROM users
    WHERE username = ? 
      AND role IN ('ADMIN', 'COUNSELOR', 'ADMIN_REPORT') 
      AND status = 'ACTIVE'
    LIMIT 1
");

$stmt->execute([$username]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($password, $user['password_hash'])) {

    session_regenerate_id(true);

    $_SESSION['user_id']  = $user['user_id'];
    $_SESSION['role'] = 'ADMIN_REPORTS';
    $_SESSION['division'] = $user['division']; 

    if ($user['role'] === 'ADMIN_REPORTS') {
        header('Location: report_admin/dashboard.php');
    } else {
        header('Location: report/dashboard.php');
    }
    exit;
}

die('Invalid username or password.');
