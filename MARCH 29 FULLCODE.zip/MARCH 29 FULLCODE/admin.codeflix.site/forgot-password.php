<?php
declare(strict_types=1);

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Ensure these paths are correct for your file structure
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/../public_html/shared/config/mail_config.php';

$submitted = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $identifier = trim($_POST['identifier'] ?? '');

    if (!empty($identifier)) {
        // FIXED SQL: Using unique placeholders for email and username
        $stmt = $pdo->prepare("
            SELECT user_id, email, username
            FROM users
            WHERE email = :email
               OR username = :username
            LIMIT 1
        ");

        // FIXED EXECUTE: Passing the identifier to both placeholders
        $stmt->execute([
            'email'    => $identifier,
            'username' => $identifier
        ]);
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Always show success message (Security best practice)
        $submitted = true;

        if ($user) {
            // Generate secure token
            $token = bin2hex(random_bytes(32));
            $expires = date('Y-m-d H:i:s', strtotime('+1 hour'));

            // Store reset token
            $stmt = $pdo->prepare("
                INSERT INTO password_resets (user_id, token, expires_at)
                VALUES (:user_id, :token, :expires_at)
            ");

            $stmt->execute([
                'user_id'    => $user['user_id'],
                'token'      => $token,
                'expires_at' => $expires
            ]);

            // Build reset link
            $link = "https://admin.codeflix.site/set-password.php?token=" . urlencode($token);

            // Email content
            $subject = "Counseling Office Reset Request";

            $body = "
                <p>Good day,</p>
                <p>A request was made to reset the password for your Counseling Office account.</p>
                <p><strong>Username:</strong> {$user['username']}</p>
                <p>Click the link below to reset your password:</p>
                <p><a href='{$link}'>Reset Password</a></p>
                <p>This link will expire in <strong>1 hour</strong>.</p>
                <p>If you did not request this reset, please ignore this email.</p>
                <p>- Counseling Office System Administrator</p>
            ";

            // Send email
            sendSystemEmail($user['email'], $subject, $body);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password | Counseling Office</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
    
    <style>
        /* ===== Reset ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        /* ===== Body ===== */
        body {
            font-family: 'Inter', "Segoe UI", Roboto, Arial, sans-serif;
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: 
                linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)),
                url("/assets/image/images.jpg") no-repeat center center;
            background-size: cover;
            color: #202124;
        }

        /* ===== Main Container ===== */
        .container {
            width: 90%;
            max-width: 450px;
            padding: 40px;
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            text-align: center;
        }

        /* ===== Icon Styling (FIXED) ===== */
        .icon-wrap {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }
        
        .icon-wrap svg {
            width: 64px;
            height: 64px;
            color: #1a73e8; /* Blue brand color */
        }

        /* ===== Title ===== */
        h2 {
            font-size: 28px;
            font-weight: 600;
            color: #202124;
            margin-bottom: 12px;
        }

        /* ===== Subtitle ===== */
        .subtitle {
            font-size: 16px;
            color: #5f6368;
            line-height: 1.5;
            margin-bottom: 30px;
        }

        /* ===== Form Styling ===== */
        .form-group {
            text-align: left;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            font-size: 14px;
            color: #3c4043;
        }

        /* ===== Input ===== */
        input[type="text"] {
            width: 100%;
            padding: 14px;
            font-size: 16px;
            border-radius: 8px;
            border: 1px solid #dadce0;
            outline: none;
            transition: 0.2s ease;
        }

        input[type="text"]:focus {
            border-color: #1a73e8;
            box-shadow: 0 0 0 2px rgba(26,115,232,0.2);
        }

        /* ===== Button ===== */
        button {
            width: 100%;
            padding: 14px;
            font-size: 16px;
            border-radius: 8px;
            border: none;
            background: #1a73e8;
            color: #fff;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.2s ease;
        }

        button:hover {
            background: #1557b0;
        }

        /* ===== Success Box (FIXED) ===== */
        .success-box {
            background-color: #e6f4ea;
            color: #137333;
            padding: 15px;
            border-radius: 8px;
            text-align: left;
            margin-bottom: 20px;
            font-size: 14px;
            border: 1px solid #ceead6;
        }
        
        .success-box strong {
            font-size: 16px;
            display: block;
            margin-bottom: 5px;
        }

        /* ===== Back Link ===== */
        .back-link {
            display: inline-block;
            margin-top: 20px;
            font-size: 14px;
            color: #1a73e8;
            text-decoration: none;
            font-weight: 500;
        }

        .back-link:hover {
            text-decoration: underline;
        }

        /* ===== Responsive ===== */
        @media (max-width: 600px) {
            .container {
                padding: 30px 20px;
            }
            h2 {
                font-size: 24px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="icon-wrap">
        <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
        </svg>
    </div>

    <h2>Forgot password?</h2>
    
    <?php if ($submitted): ?>
        
        <div class="success-box">
            <strong>Check your email!</strong>
            If an account exists with that <b>username</b> or <b>email</b>, we've sent a password reset link to the registered email address.
        </div>
        
        <p class="subtitle" style="font-size: 14px; margin-bottom: 10px;">
            Did not receive the email? Check your spam folder or try again.
        </p>

        <a href="/index.php" class="back-link">← Back to Login</a>

    <?php else: ?>

        <p class="subtitle">
            Enter your username or email address and we will send you a link to reset your password.
        </p>

        <form method="POST">
            <div class="form-group">
                <label for="identifier">Email or Username</label>
                <input 
                    type="text" 
                    id="identifier" 
                    name="identifier" 
                    placeholder="e.g. johndoe or john@example.com" 
                    required 
                    autocomplete="username"
                >
            </div>
            
            <button type="submit">Send Reset Link</button>
        </form>

        <a href="/index.php" class="back-link">← Back to Login</a>

    <?php endif; ?>
</div>

</body>
</html>